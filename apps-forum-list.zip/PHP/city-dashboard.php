<?php 
include('header-section.php');
include('left-sidebar.php');
include('ui-section.php');
?>
<!--------------City Dashboard Start -->

<div class="app-main__outer">
<div class="app-main__inner">
<div class="app-inner-layout">
<div class="app-inner-layout__header-boxed p-0">
<div class="app-inner-layout__header page-title-icon-rounded text-white bg-premium-dark mb-4">
<div class="app-page-title">
<div class="page-title-wrapper">
<div class="page-title-heading">
<div class="page-title-icon"><i class="pe-7s-umbrella icon-gradient bg-sunny-morning"></i></div>
<div>
City Dashboard - .<div class="page-title-subheading"></div>
</div>
</div>
<div class="page-title-actions">
<button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
<i class="fa fa-star"></i>
</button>
<div class="d-inline-block dropdown">
<button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn-shadow dropdown-toggle btn btn-info">
<span class="btn-icon-wrapper pr-2 opacity-7">
<i class="fa fa-business-time fa-w-20"></i>
</span>
 Buttons
</button>
<div tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu dropdown-menu-right">
<ul class="nav flex-column">
<li class="nav-item">
<a class="nav-link">
<i class="nav-link-icon lnr-inbox"></i>
<span> Inbox</span>
<div class="ml-auto badge badge-pill badge-secondary">86</div>
</a>
</li>
<li class="nav-item">
<a class="nav-link">
<i class="nav-link-icon lnr-book"></i>
<span> Book</span>
<div class="ml-auto badge badge-pill badge-danger">5</div>
</a>
</li>
<li class="nav-item">
<a class="nav-link">
<i class="nav-link-icon lnr-picture"></i>
<span> Picture</span>
</a>
</li>
<li class="nav-item">
<a disabled class="nav-link disabled">
<i class="nav-link-icon lnr-file-empty"></i>
<span> File Disabled</span>
</a>
</li>
</ul>
</div>
</div>
</div> </div>
</div>
</div>
</div> <div class="container">

</div>
<div class="row">

<!---- city menu 1--------------------------------------------------------------------------------------->
<div class="col-lg-6 col-xl-4">
<div class="mb-3 card">
<div class="card-header-tab card-header">
<div class="card-header-title font-size-lg text-capitalize font-weight-normal">
<i class="header-icon lnr-laptop-phone mr-3 text-muted opacity-6"> </i>CITY 1
</div>

</div>
<div class="pt-2 pb-0 card-body">
<h6 class="text-muted text-uppercase font-size-md opacity-9 mb-2 font-weight-normal">Booking Details </br>
</h6>
<div class="scroll-area-md shadow-overflow">
<div class="scrollbar-container">
<ul class="rm-list-borders rm-list-borders-scroll list-group list-group-flush">




<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Bookings Received</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>200</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











<!---- data 2---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Assigned</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>189</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Finished</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>185</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Completed</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>182</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Pending for approval </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>10</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Approved</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>170</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Referred Back   </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>2</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











</ul>
</div>
</div>
</div>
<div class="d-block text-center rm-border card-footer">
<button class="btn btn-primary">
City Tables<span class="text-white pl-2 opacity-3">
<i class="fa fa-arrow-right"></i>
</span>
</button>
</div>
</div>
</div>
<!---- city menu 2 ------------------------------------------------------------------------------------>




<!---- city menu 1--------------------------------------------------------------------------------------->
<div class="col-lg-6 col-xl-4">
<div class="mb-3 card">
<div class="card-header-tab card-header">
<div class="card-header-title font-size-lg text-capitalize font-weight-normal">
<i class="header-icon lnr-laptop-phone mr-3 text-muted opacity-6"> </i>CITY 2
</div>

</div>
<div class="pt-2 pb-0 card-body">
<h6 class="text-muted text-uppercase font-size-md opacity-9 mb-2 font-weight-normal">Booking Details </br>
</h6>
<div class="scroll-area-md shadow-overflow">
<div class="scrollbar-container">
<ul class="rm-list-borders rm-list-borders-scroll list-group list-group-flush">




<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Bookings Received</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>200</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











<!---- data 2---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Assigned</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>189</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Finished</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>185</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Completed</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>182</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Pending for approval </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>10</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Approved</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>170</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Referred Back   </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>2</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











</ul>
</div>
</div>
</div>
<div class="d-block text-center rm-border card-footer">
<button class="btn btn-primary">
City Tables<span class="text-white pl-2 opacity-3">
<i class="fa fa-arrow-right"></i>
</span>
</button>
</div>
</div>
</div>
<!---- city menu 3 ------------------------------------------------------------------------------------>


<!---- city menu 1--------------------------------------------------------------------------------------->
<div class="col-lg-6 col-xl-4">
<div class="mb-3 card">
<div class="card-header-tab card-header">
<div class="card-header-title font-size-lg text-capitalize font-weight-normal">
<i class="header-icon lnr-laptop-phone mr-3 text-muted opacity-6"> </i>CITY 3
</div>

</div>
<div class="pt-2 pb-0 card-body">
<h6 class="text-muted text-uppercase font-size-md opacity-9 mb-2 font-weight-normal">Booking Details </br>
</h6>
<div class="scroll-area-md shadow-overflow">
<div class="scrollbar-container">
<ul class="rm-list-borders rm-list-borders-scroll list-group list-group-flush">




<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Bookings Received</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>200</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











<!---- data 2---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Assigned</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>189</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Finished</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>185</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Completed</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>182</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Pending for approval </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>10</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Approved</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>170</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Referred Back   </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>2</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











</ul>
</div>
</div>
</div>
<div class="d-block text-center rm-border card-footer">
<button class="btn btn-primary">
City Tables<span class="text-white pl-2 opacity-3">
<i class="fa fa-arrow-right"></i>
</span>
</button>
</div>
</div>
</div>
<!---- city menu 3 ------------------------------------------------------------------------------------>


<!---- city menu 1--------------------------------------------------------------------------------------->
<div class="col-lg-6 col-xl-4">
<div class="mb-3 card">
<div class="card-header-tab card-header">
<div class="card-header-title font-size-lg text-capitalize font-weight-normal">
<i class="header-icon lnr-laptop-phone mr-3 text-muted opacity-6"> </i>CITY 4
</div>

</div>
<div class="pt-2 pb-0 card-body">
<h6 class="text-muted text-uppercase font-size-md opacity-9 mb-2 font-weight-normal">Booking Details </br>
</h6>
<div class="scroll-area-md shadow-overflow">
<div class="scrollbar-container">
<ul class="rm-list-borders rm-list-borders-scroll list-group list-group-flush">




<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Bookings Received</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>200</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











<!---- data 2---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Assigned</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>189</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Finished</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>185</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Completed</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>182</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Pending for approval </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>10</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Approved</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>170</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Referred Back   </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>2</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











</ul>
</div>
</div>
</div>
<div class="d-block text-center rm-border card-footer">
<button class="btn btn-primary">
City Tables<span class="text-white pl-2 opacity-3">
<i class="fa fa-arrow-right"></i>
</span>
</button>
</div>
</div>
</div>
<!---- city menu 4 ------------------------------------------------------------------------------------>

<!---- city menu 1--------------------------------------------------------------------------------------->
<div class="col-lg-6 col-xl-4">
<div class="mb-3 card">
<div class="card-header-tab card-header">
<div class="card-header-title font-size-lg text-capitalize font-weight-normal">
<i class="header-icon lnr-laptop-phone mr-3 text-muted opacity-6"> </i>CITY 5
</div>

</div>
<div class="pt-2 pb-0 card-body">
<h6 class="text-muted text-uppercase font-size-md opacity-9 mb-2 font-weight-normal">Booking Details </br>
</h6>
<div class="scroll-area-md shadow-overflow">
<div class="scrollbar-container">
<ul class="rm-list-borders rm-list-borders-scroll list-group list-group-flush">




<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Bookings Received</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>200</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











<!---- data 2---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Assigned</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>189</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Finished</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>185</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Completed</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>182</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Pending for approval </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>10</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Approved</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>170</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Referred Back   </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>2</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











</ul>
</div>
</div>
</div>
<div class="d-block text-center rm-border card-footer">
<button class="btn btn-primary">
City Tables<span class="text-white pl-2 opacity-3">
<i class="fa fa-arrow-right"></i>
</span>
</button>
</div>
</div>
</div>
<!---- city menu 5 ------------------------------------------------------------------------------------>

<!---- city menu 1--------------------------------------------------------------------------------------->
<div class="col-lg-6 col-xl-4">
<div class="mb-3 card">
<div class="card-header-tab card-header">
<div class="card-header-title font-size-lg text-capitalize font-weight-normal">
<i class="header-icon lnr-laptop-phone mr-3 text-muted opacity-6"> </i>CITY 6
</div>

</div>
<div class="pt-2 pb-0 card-body">
<h6 class="text-muted text-uppercase font-size-md opacity-9 mb-2 font-weight-normal">Booking Details </br>
</h6>
<div class="scroll-area-md shadow-overflow">
<div class="scrollbar-container">
<ul class="rm-list-borders rm-list-borders-scroll list-group list-group-flush">




<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Bookings Received</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>200</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











<!---- data 2---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Assigned</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>189</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Finished</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>185</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Completed</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>182</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Pending for approval </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>10</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Approved</div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>170</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>






<!---- data 1---------->


<li class="list-group-item">
<div class="widget-content p-0">
<div class="widget-content-wrapper">
<div class="widget-content-left mr-3">
<div class="icon-wrapper m-0">
<div class="progress-circle-wrapper">
<div class="progress-circle-wrapper">
<div class="circle-progress circle-progress-danger">
<small></small>
</div>
</div>
</div>
</div>
</div>
</br>
<div class="widget-content-left">
<div class="widget-heading">Referred Back   </div>
<div class="widget-subheading mt-1 opacity-10">
<div class="badge badge-pill badge-dark"></div>
</div>
</div>
<div class="widget-content-right">
<div class="fsize-1 text-focus">
<small class="opacity-5 pr-1"></small>
<span>2</span>
<small class="text-warning pl-2">
</small>
</div>
</div>
</div>
</div>
</li>











</ul>
</div>
</div>
</div>
<div class="d-block text-center rm-border card-footer">
<button class="btn btn-primary">
City Tables<span class="text-white pl-2 opacity-3">
<i class="fa fa-arrow-right"></i>
</span>
</button>
</div>
</div>
</div>
<!---- city menu 6 ------------------------------------------------------------------------------------>

</div>
<div class="app-drawer-wrapper">

<div class="drawer-content-wrapper">
<div class="scrollbar-container">
<div class="drawer-section">
<div class="notifications-box">
<div class="vertical-time-simple vertical-without-time vertical-timeline vertical-timeline--one-column">
<div class="vertical-timeline-item dot-danger vertical-timeline-element">
<div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="app-drawer-overlay d-none animated fadeIn"></div><script type="text/javascript" src="assets/scripts/main.d810cf0ae7f39f28f336.js"></script></body>

</html>
<!--------------City Dashboard End -->
